# Damary Portfolio Site

This is a simple static portfolio site that is ready for GitHub Pages.

## Files
- `index.html` — main website file

## How to publish on GitHub Pages
1. Create a repository named `damaryayala.github.io` on your GitHub account.
2. Upload `index.html` into that repository.
3. Commit the file to the `main` branch.
4. Go to **Settings > Pages**.
5. Under **Build and deployment**, select:
   - **Source:** Deploy from a branch
   - **Branch:** `main` and `/root`
6. Save.
7. Your site should publish at:
   `https://damaryayala.github.io/`

## How to edit later
Open `index.html` in any text editor and update the text, links, or sections. Then re-upload the edited file to GitHub.

## Recommended next updates
- Add your SQL project GitHub link
- Add your future Python project
- Add your Data Quality Dashboard when ready
